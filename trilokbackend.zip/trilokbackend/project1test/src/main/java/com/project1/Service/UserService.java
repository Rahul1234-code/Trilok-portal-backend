package com.project1.Service;

import org.springframework.http.ResponseEntity;

import com.project1.Model.User;

public interface UserService {

	ResponseEntity<User> LoginUser(User userdata);

}
