package com.project1.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project1.Model.User;
import com.project1.Repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public ResponseEntity<User> LoginUser(User userdata) {
	User user= userRepository.findByUsername(userdata.getUsername());
	System.out.println(userdata.getUsername());
	 if(user.getPassword().equals(userdata.getPassword())&& user.getRole().equals(userdata.getRole()))
		 return ResponseEntity.ok(user);
	 else 
		 return (ResponseEntity<User>) ResponseEntity.internalServerError();
}
}

